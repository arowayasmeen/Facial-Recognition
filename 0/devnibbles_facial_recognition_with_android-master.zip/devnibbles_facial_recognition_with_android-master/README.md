Source Code to DevNibbles article - Facial Recognition with Android

Part 1 - https://medium.com/devnibbles/facial-recognition-with-android-1-4-5e043c264edc  
Part 2 - https://medium.com/devnibbles/facial-recognition-with-android-2-4-d02f03f2a11e
